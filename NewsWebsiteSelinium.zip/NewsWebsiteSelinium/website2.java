import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class website2 {
    public void method1() {
            System.setProperty("webdriver.chrome.driver","C:/Users/Hp/Desktop/Textbook/3rd yr/2nd semester/SE 2/lab/chromedriver.exe");
            WebDriver driver = new ChromeDriver();

            driver.navigate().to("https://http://www.skysports.com/");
            WebElement title = driver.findElement(By.xpath("/html/body/h2[5]/div/span"));
            WebElement body = driver.findElement(By.xpath("/html/body/div[11]/div/div"));
            title.getText();
            System.out.println(title.getText());
            System.out.println(body.getText());


            WebDriver news = new ChromeDriver();
            news.navigate().to("http://localhost:4200/index.html");
            news.findElement(By.id("newtitle")).sendKeys(title.getText());
            news.findElement(By.id("search-input")).sendKeys(body.getText());
            news.findElement(By.name("addnews")).click();

            driver.navigate().to("http://www.espn.com/");
            WebElement title2 = driver.findElement(By.xpath("/html/body/div[6]/section/section/div/section[3]/div[1]/header"));
            WebElement body2 = driver.findElement(By.xpath("/html/body/div[6]/section/section/div/section[3]/div[1]/section"));
            System.out.println(title2.getText());
            System.out.println(body2.getText());

            news.navigate().refresh();

            news.findElement(By.id("newtitle")).sendKeys(title2.getText());
            news.findElement(By.id("search-input")).sendKeys(body2.getText());
            news.findElement(By.name("addnews")).click();





            try {
                Thread.sleep(10000);
            }catch (Exception E){

            }
            driver.close();
            news.close();
        }
    }


