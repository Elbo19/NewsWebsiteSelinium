public class website1 {
    public static void main(String[] args) {
        website2 m = new website2();
        m.method1();
    }
}
