var express = require('express');
var fs = require('fs');

var app = express();

app.use(express.static('public'));

var jstext;
var loginJsonObject;
var counter = 1;



fs.readFile("./articles.json", null, function(error, data) {
    if (error) {
        console.log("JSON file not found");
    } else {
        data = data.toString().trim();
        JSON.parse(JSON.stringify(data));
    }
});



app.get('/addnews', function(request, response) {
    var title = request.query["title"].trim();
    var body = request.query["body"].trim();

    console.log("The article is being processed.");

    jstext[title] = body;

    fs.writeFile("./articles.json", JSON.stringify(jstext), function(err) {});

});

app.get('/news', function(request, response) {
    var foundArticles = false;
    var html = "<html><title>News Website</title></body>"

    for (var i in news) {
        html += "<news><h3>" + i + "</h3><br><p>" + news[i] + "</p><news><br><br>";
        foundArticles = true;
    }

    html += "<h3>No News Found</h3>";
    html += "</body></html>";

    response.header('Content-Type', 'text/html')
    response.send(html);
})



app.listen(4200);